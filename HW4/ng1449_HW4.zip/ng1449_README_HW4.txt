In order to run this program, please include the 'cran.all.1400', 'cran.qry', and stop_list.py files within the same directory. After doing so, in commandline, please include the desired output file name in the arguments. For example:

python3 ng1449_TFIDF_HW4.py output.txt

In enhance and add additions to the system, I decided to normalize the term frequency calculation by dividing the term frequency by the length of the document/query. 

The hardest part about this program was understanding which data structures to use in order to make the necessary data storage and calculations. 